import idaapi
import idc
from collections import deque # 用于 BFS 遍历

# 获取地址所在的基本块
def get_basic_block(ea):
    func = idaapi.get_func(ea)
    if not func:
        return None
    f = idaapi.FlowChart(func) # 获取函数的控制流图
    for block in f:
        if block.start_ea <= ea < block.end_ea:
            return block
    return None

# 查找循环头（主分发器）
def find_loop_head(start_ea):
    loop_heads = set()
    queue = deque() # BFS 队列
    blcok = get_basic_block(start_ea) # 获取起始地址所在的基本块
    queue.append((blcok,[]))
    while len(queue) > 0:
        cur_block, path = queue.popleft()
        if cur_block.start_ea in path:
            loop_heads.add(cur_block.start_ea) # 找到循环头
            continue
        path = path + [cur_block.start_ea] # 更新路径
        queue.extend((s, path) for s in cur_block.succs()) # 将后继加入队列
    
    all_loop_heads = list(loop_heads)
    all_loop_heads.sort() # 升序排序，确保主循环头在第一个
    return all_loop_heads

# 查找汇聚地址(预处理器)
def find_converge_addr(loop_head_addr):
    converge_addr = None
    block = get_basic_block(loop_head_addr) # 循环头
    preds = block.preds() # 获取前驱基本块
    pred_list = list(preds)

    if len(pred_list) == 2: # 标准 ollvm：循环头有两个前驱,一个序言块一个汇聚块
        for pred in pred_list:
            tmp_list = list(pred.preds())
            if len(tmp_list) > 1: # 有多个前驱的块是汇聚块
                converge_addr = pred.start_ea
    else: # 非标准 ollvm：循环头只有一个前驱,需要继续向前找
        converge_addr = loop_head_addr
    return converge_addr

# 获取基本块大小
def get_block_size(block):
    return block.end_ea - block.start_ea

# 查找 ret 块地址
def find_ret_block(blocks):
    for block in blocks:
        succs = list(block.succs()) # 获取后继块
        succs_list = list(succs)

        end_ea = block.end_ea # end_ea 指向基本块最后一条指令的下一个地址
        last_inst_ea = idc.prev_head(end_ea) # 获取基本块最后一条指令地址
        mnem = idc.print_insn_mnem(last_inst_ea) # 获取指令助记符

        if len(succs_list) == 0: # 没有后继块
            if mnem == "RET": # 最后一条指令是 ret 指令
                ori_ret_block = block

                # 向上寻找更合适的 ret 块
                while True:
                    tmp_block = block.preds()
                    pred_list = list(tmp_block)
                    if len(pred_list) == 1: # 只有一个前驱
                        block = pred_list[0]
                        if get_block_size(block) == 4: # 单指令块
                            continue
                        else:
                            break
                    else: # 多个前驱或者无前驱
                        break
    
                # 处理子分发器情况
                block2 = block
                num = 0
                i = 0
                while True:
                    i += 1
                    succs_block = block2.succs()
                    for succ in succs_block:
                        child_succs = succ.succs()
                        succ_list = list(child_succs)
                        if len(succ_list) != 0:
                            block2 = succ
                            num += 1
                    if num > 2:
                        block = ori_ret_block
                        break
                    if i > 2:
                        break
                return block.start_ea

# 最后返回的 block ：
# 如果有单跳转->回溯到上一个真实块
# 如果有子分发器->回退到 ori_ret_block
# 否则就是一开始找到的 ret 块

# 查找所有真实块
def find_all_real_blocks(fun_ea):
    blocks = idaapi.FlowChart(idaapi.get_func(fun_ea))

    # 获取循环头
    loop_heads = find_loop_head(fun_ea)
    print(f"循环头数量: {len(loop_heads)}----{[hex(x) for x in loop_heads]}")
    all_real_blocks = []

    #对每个循环头分析真实块
    for loop_head_addr in loop_heads:
        loop_head_block = get_basic_block(loop_head_addr)
        loop_head_preds = list(loop_head_block.preds())
        loop_head_preds_addr = [b.start_ea for b in loop_head_preds]

        converge_addr = find_converge_addr(loop_head_addr)
        real_blocks = []

        # 从循环头的前驱里剔除汇聚块，剩下序言块
        if loop_head_addr != converge_addr:
            loop_head_preds_addr.remove(converge_addr)
            real_blocks.extend(loop_head_preds_addr)

        # 分析汇聚块前驱，找真实块
        converge_block = get_basic_block(converge_addr)
        list_preds = list(converge_block.preds())
        for pred in list_preds:
            end_ea = pred.end_ea
            last_inst_ea = idc.prev_head(end_ea)
            mnem = idc.print_insn_mnem(last_inst_ea)

            size = get_block_size(pred)
            if size > 4 and "B." not in mnem: # 大于单指令块且不是跳转指令
                start_ea = pred.start_ea
                mnem = idc.print_insn_mnem(start_ea)
                if mnem == "CSEL": # 处理条件选择指令
                    csel_preds = pred.preds()
                    for csel_pred in csel_preds:
                        real_blocks.append(csel_pred.start_ea)
                else:
                    real_blocks.append(start_ea)

        real_blocks.sort() # 排序，第一个是序言块
        all_real_blocks.append(real_blocks)
        print("子循环头:", [hex(child_block_ea) for child_block_ea in real_blocks])

    # 添加返回块
    ret_addr = find_ret_block(blocks)
    all_real_blocks.append(ret_addr)
    print("all_real_blocks:",all_real_blocks)

    # 合并所有真实块地址
    all_real_block_list = []
    for real_blocks in all_real_blocks:
        if isinstance(real_blocks,list):
            all_real_block_list.extend(real_blocks)
        else:
            all_real_block_list.append(real_blocks)

    print("\n所有真实块获取完成")
    print(all_real_block_list)
    print(f"真实块数量: {len(all_real_block_list)}")
    print([hex(x) for x in all_real_block_list],"\n")

    # 分析子序言块
    all_child_prologue_addr = all_real_blocks.copy()
    all_child_prologue_addr.remove(ret_addr)
    all_child_prologue_addr.remove(all_child_prologue_addr[0])  # 移除主序言块
    print("所有子序言块相关的真实块地址:", all_child_prologue_addr)
    
    # 获取子序言块的最后指令地址
    all_child_prologue_last_ins_ea = []
    for child_prologue_array in all_child_prologue_addr:
        child_prologue_addr = child_prologue_array[0]
        child_prologue_block = get_basic_block(child_prologue_addr)
        child_prologue_end_ea = child_prologue_block.end_ea
        child_prologue_last_ins_ea = idc.prev_head(child_prologue_end_ea)
        all_child_prologue_last_ins_ea.append(child_prologue_last_ins_ea)
    
    print("所有子序言块的最后一条指令的地址:", all_child_prologue_last_ins_ea)
    
    return all_real_blocks, all_child_prologue_addr, all_child_prologue_last_ins_ea


func_ea = 0x41D08
reals = find_all_real_blocks(func_ea)